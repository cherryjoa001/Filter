// ==UserScript==
// @name         Touch Fullscreen Toggle
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  손가락 동시 터치 시 전체화면(상하단바 숨김) 토글
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let lastToggleTime = 0;
    const COOLDOWN_MS = 100; // 연속 실행 방지 (0.1초 쿨타임)

    function toggleFullScreen() {
        const now = Date.now();
        // 쿨타임 미달 시 즉시 종료
        if (now - lastToggleTime < COOLDOWN_MS) return;
        lastToggleTime = now;

        const isFullscreen = document.fullscreenElement || document.webkitFullscreenElement;

        if (!isFullscreen) {
            // 전체화면 진입
            const docEl = document.documentElement;
            if (docEl.requestFullscreen) {
                docEl.requestFullscreen().catch(() => {});
            } else if (docEl.webkitRequestFullscreen) {
                docEl.webkitRequestFullscreen();
            }
        } else {
            // 전체화면 해제
            if (document.exitFullscreen) {
                document.exitFullscreen().catch(() => {});
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }

    // 터치 이벤트 감지 (빠른 탈출 적용)
    window.addEventListener('touchstart', function (e) {
        // 렉 방지
        if (!e.touches || e.touches.length !== 4) return;

        toggleFullScreen();
    }, { passive: true });
})();
