// ==UserScript==
// @name         Mobile Video Gesture
// @namespace    http://tampermonkey.net/
// @version      12.4.0
// @description  모바일 비디오 제스쳐
// @license      MIT
// @exclude      *://*.youtube*
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
  'use strict';

  if (window.__mobileVideoGesture__) return;
  window.__mobileVideoGesture__ = true;

  const state = {
    blockUntil: 0,
    isSeeking: false,
    isLongPressing: false,

    video: null,
    ctrl: null,

    // Seek 관련
    startX: 0,
    startY: 0,
    initTime: 0,
    pendingTime: null,
    overlayInit: false,
    rafId: null,

    // Long Press 관련
    lpTimer: null,
    originalStyles: new Map(),

    // Controllers
    gestureAbort: null,
    mediaAbort: null
  };

  const userPlaybackRates = new WeakMap();

  function createVideoController(video) {
    let getRealTime, setRealTime, getDur, getSpeed, setSpeed;

    if (typeof video?.player?.currentTime === 'function') {
      getRealTime = () => video.player.currentTime(); setRealTime = (t) => video.player.currentTime(t);
      getDur = () => video.player.duration();
      getSpeed = () => video.player.playbackRate(); setSpeed = (r) => video.player.playbackRate(r);
    } else if (video?.plyr) {
      getRealTime = () => video.plyr.currentTime; setRealTime = (t) => { video.plyr.currentTime = t; };
      getDur = () => video.plyr.duration;
      getSpeed = () => video.plyr.speed; setSpeed = (r) => { video.plyr.speed = r; };
    } else if (video?.shakaPlayer) {
      getRealTime = () => video.shakaPlayer.getMediaElement().currentTime; setRealTime = (t) => { video.shakaPlayer.getMediaElement().currentTime = t; };
      getDur = () => video.shakaPlayer.getDuration();
      getSpeed = () => video.shakaPlayer.getPlaybackRate(); setSpeed = (r) => video.shakaPlayer.setPlaybackRate(r);
    } else {
      getRealTime = () => video.currentTime ?? 0; setRealTime = (t) => { video.currentTime = t; };
      getDur = () => video.duration ?? 0;
      getSpeed = () => video.playbackRate ?? 1; setSpeed = (r) => { video.playbackRate = r; };
    }

    return {
      el: video,
      get currentTime() { try { return getRealTime(); } catch { return 0; } },
      set currentTime(t) { try { setRealTime(t); } catch {} },
      get duration() { try { return getDur(); } catch { return 0; } },
      get playbackRate() { try { return getSpeed(); } catch { return 1; } },
      set playbackRate(r) { try { setSpeed(r); } catch {} },
    };
  }

  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed', background: 'rgba(0, 0, 0, 0.1)', color: '#fff',
    borderRadius: '6px', textAlign: 'center', zIndex: 2147483647,
    display: 'none', lineHeight: '1.4', pointerEvents: 'none', boxSizing: 'border-box',
    whiteSpace: 'pre-line'
  });
  document.body.appendChild(overlay);

  function showOverlay(video, text, type = 'center') {
    const fsEl = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
    const target = fsEl || document.body;
    if (overlay.parentElement !== target) target.appendChild(overlay);

    const r = video.getBoundingClientRect();
    if (type === 'center') {
      Object.assign(overlay.style, {
        left: `${r.left + r.width / 2}px`, top: `${r.top + r.height / 10}px`,
        transform: 'translate(-50%, -50%)', fontSize: '16px', fontWeight: 'bold', padding: '8px 16px'
      });
    } else {
      Object.assign(overlay.style, {
        left: `${r.left + 12}px`, top: `${r.top + 12}px`,
        transform: 'none', fontSize: '13px', fontWeight: '600', padding: '4px 8px'
      });
    }
    overlay.innerText = text;
    overlay.style.display = 'block';
  }

  function hideOverlay() {
    overlay.style.display = 'none';
    overlay.innerText = '';
  }

  const padTime = n => n.toString().padStart(2, '0');
  function formatTime(seconds, isDelta = false) {
    if (isNaN(seconds)) return '00:00';
    const sign = isDelta ? (seconds < 0 ? '-' : '+') : '';
    const abs = Math.floor(Math.abs(seconds));
    const h = Math.floor(abs / 3600), m = Math.floor((abs % 3600) / 60), s = abs % 60;
    return h > 0 ? `${sign}${padTime(h)}:${padTime(m)}:${padTime(s)}` : `${sign}${padTime(m)}:${padTime(s)}`;
  }

  function getVideoZone(clientX, clientY, target) {
    let video = target?.closest?.('video');
    if (!video && (target?.shadowRoot || ['DIV', 'SPAN', 'IMG', 'A'].includes(target?.tagName))) {
      for (const el of document.elementsFromPoint(clientX, clientY)) {
        if (el.tagName === 'VIDEO') { video = el; break; }
        if (el.shadowRoot) {
          const shadowVid = el.shadowRoot.querySelector('video');
          if (shadowVid) { video = shadowVid; break; }
        }
      }
    }

    if (!video) return { video: null, isTopLeft: false, isCenter: false };
    const r = video.getBoundingClientRect();
    if (r.width === 0 || r.height === 0 || clientX < r.left || clientX > r.right || clientY < r.top || clientY > r.bottom) {
      return { video: null, isTopLeft: false, isCenter: false };
    }

    const isTopLeft = clientX <= r.left + r.width / 3 && clientY <= r.top + r.height / 3;
    const isCenter = clientX >= r.left + r.width / 3 && clientX <= r.left + (r.width * 2) / 3 &&
                     clientY >= r.top + r.height / 4 && clientY <= r.top + (r.height * 3) / 4;

    return { video, isTopLeft, isCenter };
  }

  function manageStyles(video, action) {
    const props = ['webkitUserSelect', 'userSelect', 'webkitTouchCallout'];
    if (action === 'apply') {
      props.forEach(p => {
        state.originalStyles.set(p, video.style[p] || '');
        video.style[p] = 'none';
      });
    } else if (action === 'restore' && video) {
      props.forEach(p => {
        const orig = state.originalStyles.get(p);
        if (orig) video.style[p] = orig;
        else video.style.removeProperty(p.replace(/([A-Z])/g, '-$1').toLowerCase());
      });
      state.originalStyles.clear();
    }
  }

  function clearState() {
    if (state.lpTimer) clearTimeout(state.lpTimer);
    if (state.rafId) cancelAnimationFrame(state.rafId);

    if (state.gestureAbort) state.gestureAbort.abort();
    if (state.mediaAbort) state.mediaAbort.abort();

    if (!state.isSeeking && !state.isLongPressing) {
        manageStyles(state.video, 'restore');
    }

    state.lpTimer = null;
    state.rafId = null;
    state.gestureAbort = null;
    state.mediaAbort = null;

    hideOverlay();
  }

  function endLongPress() {
    state.isLongPressing = false;
    try {
      if (state.video && state.ctrl) {
        state.ctrl.playbackRate = userPlaybackRates.get(state.video) ?? 1;
        userPlaybackRates.delete(state.video);
      }
    } catch (e) {}

    manageStyles(state.video, 'restore');
    state.video = null;
    state.ctrl = null;
    clearState();
  }

  function endSeek() {
    if (state.pendingTime !== null && state.ctrl) {
        state.ctrl.currentTime = state.pendingTime;
    }
    state.isSeeking = false;
    state.overlayInit = false;
    state.pendingTime = null;
    state.video = null;
    state.ctrl = null;
    clearState();
  }

  function interceptEnd(e) {
    if (state.lpTimer && !state.isLongPressing) {
      clearState();
      state.video = null; state.ctrl = null;
    }

    const now = Date.now();
    if (state.isSeeking || state.isLongPressing || now < state.blockUntil) {
      e.stopPropagation();
      e.stopImmediatePropagation();
      if (e.cancelable) e.preventDefault();

      state.blockUntil = now + 50;
      if (state.isSeeking) endSeek();
      if (state.isLongPressing) endLongPress();
    } else {
      state.video = null; state.ctrl = null;
    }
  }

  function handleTouchMove(e) {
    if (!state.isLongPressing && !state.lpTimer && !state.video) return;

    if (state.isLongPressing) {
      if (e.cancelable) e.preventDefault();
      return;
    }

    // 롱프레스 발동 전에 움직이면 취소
    if (state.lpTimer && !state.isLongPressing) {
      clearState();
      state.video = null; state.ctrl = null;
    }

    if (state.video && e.touches.length === 1) {
      const t = e.touches[0];
      const dx = t.clientX - state.startX;
      const dy = t.clientY - state.startY;

      if (!state.isSeeking) {
        if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy)) state.isSeeking = true;
        else if (Math.abs(dy) > 10) {
          state.video = null;
          clearState();
          return;
        }
      }

      if (state.isSeeking && state.ctrl) {
        if (e.cancelable) e.preventDefault();

        const timeChange = dx * 0.2;
        state.pendingTime = Math.max(0, Math.min(state.initTime + timeChange, state.ctrl.duration));

        if (!state.overlayInit) {
            showOverlay(state.video, '', 'center');
            state.overlayInit = true;
        }

        if (state.rafId) cancelAnimationFrame(state.rafId);
        state.rafId = requestAnimationFrame(() => {
            overlay.innerText = `${formatTime(state.pendingTime)}\n(${formatTime(timeChange, true)})`;
        });
      }
    }
  }

  ['touchend', 'touchcancel', 'pointerup', 'pointercancel', 'click', 'mouseup'].forEach(evt => {
    window.addEventListener(evt, interceptEnd, { capture: true, passive: false });
  });

  window.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1 || Date.now() < state.blockUntil) return;
    const t = e.touches[0];
    const { video, isTopLeft, isCenter } = getVideoZone(t.clientX, t.clientY, e.target);

    if (!video) return;

    state.video = video;
    state.ctrl = createVideoController(video);
    clearState();

    state.gestureAbort = new AbortController();
    window.addEventListener('touchmove', handleTouchMove, { passive: false, capture: true, signal: state.gestureAbort.signal });
    window.addEventListener('scroll', forceRelease, { capture: true, passive: true, signal: state.gestureAbort.signal });

    if (isCenter) {
      state.startX = t.clientX;
      state.startY = t.clientY;
      state.initTime = state.ctrl.currentTime;
      state.isSeeking = false;
      state.overlayInit = false;
      state.pendingTime = null;

    } else if (!isTopLeft) {
      state.isLongPressing = false;
      manageStyles(video, 'apply');

      state.lpTimer = setTimeout(() => {
        state.isLongPressing = true;
        userPlaybackRates.set(video, state.ctrl.playbackRate);
        state.ctrl.playbackRate = 2.0;
        showOverlay(video, 'x2', 'speed');

        state.mediaAbort = new AbortController();
        const handleInterrupt = () => { if (state.isLongPressing) endLongPress(); };

        ['error', 'pause', 'ended'].forEach(evt => {
           video.addEventListener(evt, handleInterrupt, { signal: state.mediaAbort.signal });
        });

        video.addEventListener('ratechange', () => {
           if (state.isLongPressing && state.ctrl && state.ctrl.playbackRate < 2.0) {
               handleInterrupt();
           }
        }, { signal: state.mediaAbort.signal });

      }, 400);
    }
  }, { passive: true, capture: true });

  window.addEventListener('contextmenu', e => {
    if (state.isLongPressing || state.lpTimer || state.isSeeking) {
      e.preventDefault();
      e.stopPropagation();
    } else {
      const { video, isTopLeft } = getVideoZone(e.clientX, e.clientY, e.target);
      if (video && !isTopLeft) { e.preventDefault(); e.stopPropagation(); }
    }
  }, { capture: true });

  const forceRelease = () => {
    if (state.isSeeking) endSeek();
    if (state.isLongPressing) endLongPress();
    clearState();
  };

  document.addEventListener('visibilitychange', () => { if (document.hidden) forceRelease(); });
  window.addEventListener('blur', forceRelease);
})();
